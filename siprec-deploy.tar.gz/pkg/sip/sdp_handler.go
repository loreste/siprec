package sip

// This file is deprecated.
// The SDP handling functionality has been moved to sdp.go
// This empty file is kept for backward compatibility during migration.
